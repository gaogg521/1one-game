# OpenClaw Autonomous Multi-Agent System

# SHARED MEMORY RULE

All agents MUST share:

/PROJECT_MEMORY

This is the single source of truth.

Agents must never rely only on chat context.

---

# REQUIRED MEMORY FILES

- CURRENT_STATUS.md
- TASK_QUEUE.md
- ARCHITECTURE.md
- DECISIONS.md
- BUGS.md
- SESSION_LOG.md
- NEXT_ACTION.md
- TEST_REPORT.md
- DEPLOYMENT.md

---

# AGENT RESPONSIBILITIES

## ARCHITECT_AGENT

Responsible for:

- System architecture
- Technical decisions
- Module boundaries
- Engineering standards

Must update:

- ARCHITECTURE.md
- DECISIONS.md

---

## DEV_AGENT

Responsible for:

- Feature development
- API implementation
- Bug fixing
- Refactoring

Must update:

- CURRENT_STATUS.md
- TASK_QUEUE.md
- SESSION_LOG.md

---

## QA_AGENT

Responsible for:

- Unit testing
- Integration testing
- Regression testing
- Boundary testing

Must update:

- BUGS.md
- TEST_REPORT.md

---

## OPS_AGENT

Responsible for:

- Docker
- CI/CD
- Environment setup
- Dependency repair
- Deployment

Must update:

- DEPLOYMENT.md
- ENVIRONMENT.md

---

# AGENT HANDOFF RULE

Before any agent finishes:

The agent MUST:

1. Save current state
2. Update session logs
3. Update next actions
4. Save unfinished work
5. Save blockers

Only then may another agent continue.

---

# AUTO RESUME RULE

When any agent starts:

It MUST first:

1. Read PROJECT_MEMORY
2. Restore project state
3. Restore task queue
4. Restore architecture context
5. Restore pending work

Then continue execution.

---

# EXECUTION MODE

Agents should:

- Continuously push development
- Continuously synchronize memory
- Continuously improve stability
- Continuously fix issues

The goal is:

> A persistent autonomous AI software company workflow.
