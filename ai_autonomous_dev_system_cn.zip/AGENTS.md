# OpenClaw 多 Agent 自动研发系统

# 共享记忆规则

所有 Agent 必须共享：

/PROJECT_MEMORY

这是整个项目唯一可信状态来源。

禁止仅依赖聊天上下文。

---

# 必须维护的记忆文件

- CURRENT_STATUS.md
- TASK_QUEUE.md
- ARCHITECTURE.md
- DECISIONS.md
- BUGS.md
- SESSION_LOG.md
- NEXT_ACTION.md
- TEST_REPORT.md
- DEPLOYMENT.md

---

# Agent 职责

## ARCHITECT_AGENT

负责：

- 系统架构
- 技术方案
- 模块边界
- 工程规范

必须更新：

- ARCHITECTURE.md
- DECISIONS.md

---

## DEV_AGENT

负责：

- 功能开发
- API开发
- Bug修复
- 重构优化

必须更新：

- CURRENT_STATUS.md
- TASK_QUEUE.md
- SESSION_LOG.md

---

## QA_AGENT

负责：

- 单元测试
- 集成测试
- 回归测试
- 边界测试

必须更新：

- BUGS.md
- TEST_REPORT.md

---

## OPS_AGENT

负责：

- Docker
- CI/CD
- 环境修复
- 依赖问题
- 部署流程

必须更新：

- DEPLOYMENT.md
- ENVIRONMENT.md

---

# Agent 交接规则

任意 Agent 完成工作后：

必须：

1. 保存当前状态
2. 更新 SESSION_LOG
3. 更新 NEXT_ACTION
4. 保存未完成工作
5. 保存当前阻塞

然后下一个 Agent 才允许接管。

---

# 自动恢复规则

任意 Agent 启动时：

必须先：

1. 读取 PROJECT_MEMORY
2. 恢复当前状态
3. 恢复任务队列
4. 恢复架构上下文
5. 恢复未完成工作

然后再继续执行。

---

# 执行模式

所有 Agent 必须持续：

- 推进研发
- 同步项目记忆
- 修复问题
- 提升稳定性
- 自动衔接下一阶段

最终目标：

> 构建可持续运行的 AI 自动化软件研发体系。
